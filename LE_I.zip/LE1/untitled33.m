%% ================================
% STEP 1: NOMINAL LOADS [nLoad x 3]
% ================================
l_bus = [5 8 9 11 12 14 15 17 20];
nLoad = length(l_bus);

%  Bus:    5      8      9     11     12     14     15     17     20
P_load = [
    60    45    45;   %  5
    80    60    60;   %  8
   120    90    90;   %  9
   160   120   120;   % 11
   100    75    75;   % 12
   140   105   105;   % 14
   120    90    90;   % 15
   100    75    75;   % 17
    88    66    66;   % 20
] * 1e3;   % in Watts

Q_load = [
    24    18    18;   %  5
    32    24    24;   %  8
    48    36    36;   %  9
    80    60    60;   % 11
    40    30    30;   % 12
    60    45    45;   % 14
    48    36    36;   % 15
    40    30    30;   % 17
    36    27    27;   % 20
] * 1e3;

P_nom_total = sum(P_load, 1);   % [1x3] per-phase total
Q_nom_total = sum(Q_load, 1);

fprintf('=== NOMINAL LOAD CHECK ===\n');
fprintf('  P total nominal: %.3f MW  (paper: 2.420 MW)\n', sum(P_nom_total)/1e6);
fprintf('  Q total nominal: %.3f Mvar (paper: 1.020 Mvar)\n\n', sum(Q_nom_total)/1e6);

%% ================================
% STEP 2: LOAD FORECASTS
% we are adding ±5% to nominal values to make them forecasted values
% ================================
%L1 — uniform ±5%
rng(1);
delta_L1 = (rand - 0.5) * 0.10;

P_L1 = P_load * (1+delta_L1);
Q_L1 = Q_load * (1+delta_L1);
%L1 — uniform ±5%
rng(42);
P_L2 = P_load .* (1 + (rand(size(P_load)) - 0.5) * 0.10);
Q_L2 = Q_load .* (1 + (rand(size(Q_load)) - 0.5) * 0.10);

%% ================================
% STEP 3: BETA
% B1 — all 5%,  B2 — bus 8 at 10%
%beta controls how much each load can change
% ================================
beta_B1 = 0.05 * ones(nLoad,1);
beta_B2 = 0.05 * ones(nLoad,1);
beta_B2(l_bus==8) = 0.10;

%% =========================================================================
% STEP 4: EXTRACT + AUTO-SCALE SIMULINK DATA
% =========================================================================
nMeas = 6;% using 6 measurements in the system

P_raw = zeros(nMeas,1);% creating empty vectors to store values extracted from simulink
Q_raw = zeros(nMeas,1);

P_raw(1) = out.P1(end,1);   % bus 1 - taking finial steady value 
P_raw(2) = out.P6(end,1);   % bus 6 - power flowing in each bus
P_raw(3) = out.P10(end,1);  % bus 10
P_raw(4) = out.P12(end,1);  % bus 12
P_raw(5) = out.P15(end,1);  % bus 15
P_raw(6) = out.P19(end,1);  % bus 19

Q_raw(1) = out.Q1(end,1);
Q_raw(2) = out.Q6(end,1);
Q_raw(3) = out.Q10(end,1);
Q_raw(4) = out.Q12(end,1);
Q_raw(5) = out.Q15(end,1);
Q_raw(6) = out.Q19(end,1);

V_raw(1) = out.V1(end,1);
V_raw(2) = out.V6(end,1);
V_raw(3) = out.V10(end,1);
V_raw(4) = out.V12(end,1);
V_raw(5) = out.V15(end,1);
V_raw(6) = out.V19(end,1);

theta_raw(1) = out.T1(end,1);
theta_raw(2) = out.T6(end,1);
theta_raw(3) = out.T10(end,1);
theta_raw(4) = out.T12(end,1);
theta_raw(5) = out.T15(end,1);
theta_raw(6) = out.T19(end,1);

% --- Noise samples ---
rng('shuffle');%adding different noise at each time
sigma = 0.01;
nP_raw = sigma * randn(nMeas,1);% randn generates gaussian(normal) noise
nQ_raw = sigma * randn(nMeas,1);% finial noise 

% --- AUTO-DETECT UNITS ---
P_nom_3ph = sum(P_nom_total);   % 2.42e6 W - total real power in system
Q_nom_3ph = sum(Q_nom_total);   % 1.02e6 VAr

fprintf('=== SIMULINK UNIT DETECTION ===\n');
fprintf('  out.P1 raw value = %.6g\n', P_raw(1));
fprintf('  Expected total P = %.6g W  (%.4f MW)\n', P_nom_3ph, P_nom_3ph/1e6);

unit_ratio_P = P_nom_3ph / abs(P_raw(1) + 1e-30);% compare expected with measured

if unit_ratio_P > 1e5 % unit detection  
    unit_scale = 1e6; % convert pu --> Watts
    fprintf('  Detected unit: PER-UNIT → scaling by 1e6\n');
elseif unit_ratio_P > 100
    unit_scale = 1e3; % convert kW --> W
    fprintf('  Detected unit: kW → scaling by 1e3\n');
elseif unit_ratio_P > 0.5 && unit_ratio_P < 2
    unit_scale = 1; % no change
    fprintf('  Detected unit: WATTS → no scaling needed\n');
elseif unit_ratio_P > 0.0005 && unit_ratio_P < 0.005
    unit_scale = 1e6; % convert MW --> W
    fprintf('  Detected unit: MW → scaling by 1e6\n');
else
    unit_scale = P_nom_3ph / abs(P_raw(1) + 1e-30); % if unknown
    fprintf('  WARNING: Unknown unit, forcing scale = %.4g\n', unit_scale);
end

% Apply Scaling(everything converting to Watts/VAr)
P_meas = P_raw * unit_scale;
Q_meas = Q_raw * unit_scale;
nP = nP_raw * unit_scale;
nQ = nQ_raw * unit_scale;

fprintf('\n=== POST-SCALING SANITY CHECK ===\n');
fprintf('  P_meas(1) [bus 1]  = %.3f kW  (should ≈ %.3f kW total nominal)\n',...
    P_meas(1)/1e3, P_nom_3ph/1e3);
fprintf('  P_meas(2) [bus 6]  = %.3f kW\n', P_meas(2)/1e3);
fprintf('  P_meas(3) [bus 10] = %.3f kW\n', P_meas(3)/1e3);
fprintf('  P_meas(4) [bus 12] = %.3f kW\n', P_meas(4)/1e3);
fprintf('  P_meas(5) [bus 15] = %.3f kW\n', P_meas(5)/1e3);
fprintf('  P_meas(6) [bus 19] = %.3f kW\n\n', P_meas(6)/1e3);

meas_error_frac = abs(P_meas(1) - P_nom_3ph) / P_nom_3ph; % error check
if meas_error_frac > 0.20 % measurements are unreliable
    fprintf('  WARNING: Scaled P_meas(1) still %.1f%% off nominal.\n', meas_error_frac*100);
    fprintf('  FALLBACK: Using nominal load sums as "true" measurements.\n\n');

    cumul_idx = {1:9, 1, 1:3, 1:4, 1:6, 1:8}; % fallback mechanism(prevents wrong scaling,garbage estimation)
    for m = 1:nMeas
        P_meas(m) = sum(sum(P_load(cumul_idx{m},:)));
        Q_meas(m) = sum(sum(Q_load(cumul_idx{m},:)));
    end
    nP = sigma * P_meas; % recomputing noise(scale and meaning of measurements changed)
    nQ = sigma * Q_meas;

    fprintf('  Recomputed P_meas(1) = %.3f kW (should = %.3f kW)\n',...
        P_meas(1)/1e3, P_nom_3ph/1e3);
end

fprintf('STEP 4 DONE: Simulink measurements extracted and scaled\n');
%% ================================
% STEP 4: MEASUREMENT SCHEMES (M1–M6)
% =================================

% -------- M1: Accurate P, Q, V, theta --------
M1.V_meas     = V_meas;
M1.P_meas     = P_meas;
M1.Q_meas     = Q_meas;
M1.theta_meas = theta;

% -------- M2: Noisy P, Q, V, theta --------
M2.V_meas     = V_meas     + noise_V;
M2.P_meas     = P_meas     + noise_P;
M2.Q_meas     = Q_meas     + noise_Q;
M2.theta_meas = theta+ noise_theta;

% -------- M3: Accurate P, Q, V --------
M3.V_meas = V_meas;
M3.P_meas = P_meas;
M3.Q_meas = Q_meas;

% -------- M4: Noisy P, Q, V --------
M4.V_meas = V_meas + noise_V;
M4.P_meas = P_meas + noise_P;
M4.Q_meas = Q_meas + noise_Q;

% -------- M5: Accurate P, Q --------
M5.P_meas = P_meas;
M5.Q_meas = Q_meas;

% -------- M6: Noisy P, Q --------
M6.P_meas = P_meas + noise_P;
M6.Q_meas = Q_meas + noise_Q;

%% ================================
% STEP 5: STORE MEASUREMENTS
% =================================

Meas.M1 = M1;
Meas.M2 = M2;
Meas.M3 = M3;
Meas.M4 = M4;
Meas.M5 = M5;
Meas.M6 = M6;

%% =========================================================================
% STEP 5: BUILD ZONE BOUNDARY MEASUREMENTS [nZones x 3]
% =========================================================================
zone_lidx = {1, [2 3], 4, [5 6], [7 8], 9}; % dividing 9 loads into 6 zones
nZones = 6;

P_zone_nom = zeros(nZones, 3); % creating zero matrices 
Q_zone_nom = zeros(nZones, 3);
for z = 1:nZones
    P_zone_nom(z,:) = sum(P_load(zone_lidx{z},:), 1); % Adding loads inside that zone
    Q_zone_nom(z,:) = sum(Q_load(zone_lidx{z},:), 1); % order [nZones×3]
end

fprintf('\n=== ZONE NOMINAL POWER CHECK ===\n'); % validation + debugging
for z = 1:nZones
    fprintf('  Zone %d: P=%.2f kW, Q=%.2f kVar  (buses: %s)\n', z,...
        sum(P_zone_nom(z,:))/1e3, sum(Q_zone_nom(z,:))/1e3,...
        num2str(l_bus(zone_lidx{z})));
end
fprintf('  Total: P=%.2f kW\n\n', sum(sum(P_zone_nom))/1e3);

% Differential zone measurements
P_zone_meas_diff = zeros(nZones, 1);
Q_zone_meas_diff = zeros(nZones, 1);

P_zone_meas_diff(1) = P_meas(2); % load in a zone = difference of flows
P_zone_meas_diff(2) = P_meas(3) - P_meas(2);
P_zone_meas_diff(3) = P_meas(4) - P_meas(3);
P_zone_meas_diff(4) = P_meas(5) - P_meas(4);
P_zone_meas_diff(5) = P_meas(6) - P_meas(5);
P_zone_meas_diff(6) = P_meas(1) - P_meas(6);

Q_zone_meas_diff(1) = Q_meas(2);
Q_zone_meas_diff(2) = Q_meas(3) - Q_meas(2);
Q_zone_meas_diff(3) = Q_meas(4) - Q_meas(3);
Q_zone_meas_diff(4) = Q_meas(5) - Q_meas(4);
Q_zone_meas_diff(5) = Q_meas(6) - Q_meas(5);
Q_zone_meas_diff(6) = Q_meas(1) - Q_meas(6);

fprintf('=== DIFFERENTIAL ZONE MEASUREMENT SANITY CHECK ===\n');
diff_ok = true;
for z = 1:nZones
    p_nom_z = sum(P_zone_nom(z,:));
    p_diff_z = P_zone_meas_diff(z);
    ratio_z  = p_diff_z / (p_nom_z + 1e-10);% compare measured and nominal
    fprintf('  Zone %d: diff=%.2f kW  nominal=%.2f kW  ratio=%.3f\n',...
        z, p_diff_z/1e3, p_nom_z/1e3, ratio_z);
    if ratio_z < 0.5 || ratio_z > 2.0 || p_diff_z < 0 % measurement is suspicious
        diff_ok = false;% to small -> missing data ; too large -> scaling issue ; -ve -> impossible
    end
end
% Fall back(preventing)
if ~diff_ok
    fprintf('\n  WARNING: Differential measurements look wrong.\n');
    fprintf('  USING NOMINAL LOADS AS ZONE MEASUREMENTS (paper baseline).\n\n');
    for z = 1:nZones
        P_zone_meas_diff(z) = sum(P_zone_nom(z,:));
        Q_zone_meas_diff(z) = sum(Q_zone_nom(z,:));
    end
else
    fprintf('\n  Differential measurements look reasonable. Using them.\n\n');
end

% Build [nZones x 3] measurement matrices(converting zone power -> 3phase power)
z_P_M1 = zeros(nZones, 3);
z_Q_M1 = zeros(nZones, 3);
z_P_M2 = zeros(nZones, 3);
z_Q_M2 = zeros(nZones, 3);
z_P_M5 = zeros(nZones, 3);
z_Q_M5 = zeros(nZones, 3);

for z = 1:nZones
    P_ztot = sum(P_zone_nom(z,:));% P_zone_nom(z,:) → [P_A, P_B, P_C] for zone z
    Q_ztot = sum(Q_zone_nom(z,:));

    if P_ztot > 1e-10
        pR = P_zone_nom(z,:) / P_ztot;% fraction of power in each zone
    else
        pR = [1/3 1/3 1/3];% phase ratio
    end
    if Q_ztot > 1e-10
        qR = Q_zone_nom(z,:) / Q_ztot;
    else
        qR = [1/3 1/3 1/3];
    end

    z_P_M1(z,:) = P_zone_meas_diff(z) * pR; % scalar total zone power
    z_Q_M1(z,:) = Q_zone_meas_diff(z) * qR;

    z_P_M2(z,:) = (P_zone_meas_diff(z) + nP(z)) * pR;% adding noise
    z_Q_M2(z,:) = (Q_zone_meas_diff(z) + nQ(z)) * qR;

    z_P_M5(z,:) = z_P_M1(z,:);
    z_Q_M5(z,:) = z_Q_M1(z,:);
end

z_P_M3 = z_P_M1;
z_Q_M3 = z_Q_M1;

fprintf('=== ZONE MEASUREMENT SUMMARY (M1) ===\n');
for z = 1:nZones
    fprintf('  Zone %d: P=[%.2f  %.2f  %.2f] kW  (nominal sum=%.2f kW)\n',...
        z, z_P_M1(z,1)/1e3, z_P_M1(z,2)/1e3, z_P_M1(z,3)/1e3,...
        sum(P_zone_nom(z,:))/1e3);
end

%% =========================================================================
% STEP 6: NO-DECOMP ZONE MEASUREMENTS (Case 5)
% =========================================================================
P_nom_ratio = P_nom_total / sum(P_nom_total);
Q_nom_ratio = Q_nom_total / sum(Q_nom_total);

P_total_meas = P_meas(1);% total power feeding the entire system
Q_total_meas = Q_meas(1);

% Sanity check( is measured total is closed to nominal total?)
if abs(P_total_meas - sum(P_nom_total)) / sum(P_nom_total) > 0.20 
    fprintf('\nNo-decomp fallback: using sum of nominal as bus-1 total\n');
    P_total_meas = sum(P_nom_total);
    Q_total_meas = sum(Q_nom_total);
end

z_P_all_M1_nd = P_total_meas * P_nom_ratio;% Total × ratio → 3-phase vector 
z_Q_all_M1_nd = Q_total_meas * Q_nom_ratio;
z_P_all_M2_nd = (P_total_meas + nP(1)) * P_nom_ratio;% adding noise
z_Q_all_M2_nd = (Q_total_meas + nQ(1)) * Q_nom_ratio;
z_P_all_M5_nd = z_P_all_M1_nd;
z_Q_all_M5_nd = z_Q_all_M1_nd;

%% ================================
% STEP 7: STRUCT PRE-ALLOCATION
% ================================
zones = struct('name',     {'Z1-GRS','Z2-SFL','Z3-SFL','Z4-SFL','Z5-SFL','Z6-SFL'}, ...
               'type',     {'GRS',   'SFL',   'SFL',   'SFL',   'SFL',   'SFL'  }, ...
               'load_idx', {zone_lidx{1}, zone_lidx{2}, zone_lidx{3}, ...
                            zone_lidx{4}, zone_lidx{5}, zone_lidx{6}} );

zones_all = struct('name',     {'ALL-GRS'}, ...
                   'type',     {'GRS'    }, ...
                   'load_idx', {1:nLoad  } );

%% ================================
% STEP 8: CONVERGENCE SETTINGS(when will iteration stop)
% ================================
S_min   = min([P_load(:); Q_load(:)]);% S_min as reference scale
epsilon = 1e-7 * S_min;%tolerance for stopping the iteration 
max_it  = 50;%( to prevent infinite loops, oscillations)
fprintf('\nEpsilon = %.4e W  (S_min=%.0f W)\n', epsilon, S_min);

%% =========================================================================
% STEP 9: TABLE I — FORECAST ERROR
% =========================================================================
fprintf('\n================================================================\n');
fprintf('  TABLE I: FORECAST ERROR (Before Estimation)\n');
fprintf('================================================================\n');
fprintf('%-5s|%7s %7s %9s %9s||%7s %7s %9s %9s\n',...
    'Bus','L1%%P','L1%%Q','L1kW','L1kVar','L2%%P','L2%%Q','L2kW','L2kVar');
fprintf('%s\n',repmat('-',1,82));
for i = 1:nLoad
    fprintf('%-5d|%7.3f %7.3f %9.4f %9.4f||%7.3f %7.3f %9.4f %9.4f\n',...
        l_bus(i),...
        max(abs((P_L1(i,:)-P_load(i,:))./P_load(i,:))*100),...
        max(abs((Q_L1(i,:)-Q_load(i,:))./Q_load(i,:))*100),...
        max(abs(P_L1(i,:)-P_load(i,:)))/1e3,...
        max(abs(Q_L1(i,:)-Q_load(i,:)))/1e3,...
        max(abs((P_L2(i,:)-P_load(i,:))./P_load(i,:))*100),...
        max(abs((Q_L2(i,:)-Q_load(i,:))./Q_load(i,:))*100),...
        max(abs(P_L2(i,:)-P_load(i,:)))/1e3,...
        max(abs(Q_L2(i,:)-Q_load(i,:)))/1e3);
end

%% =========================================================================
% STEP 10: ALL 10 CASES
% =========================================================================
fprintf('\n=========================================\n');
fprintf('   RUNNING ALL 10 CASES\n');
fprintf('=========================================\n');

[P_1a,Q_1a,nit_1a,dh_1a] = run_swp(P_L1,Q_L1,beta_B1,zones,z_P_M1,z_Q_M1,max_it,epsilon);
fprintf('Case 1.a (L1+B1+M1): %d iters  [paper: 4]\n',nit_1a);

[P_1b,Q_1b,nit_1b,dh_1b] = run_swp(P_L1,Q_L1,beta_B2,zones,z_P_M1,z_Q_M1,max_it,epsilon);
fprintf('Case 1.b (L1+B2+M1): %d iters  [paper: 4]\n',nit_1b);

[P_2a,Q_2a,nit_2a,dh_2a] = run_swp(P_L2,Q_L2,beta_B1,zones,z_P_M1,z_Q_M1,max_it,epsilon);
fprintf('Case 2.a (L2+B1+M1): %d iters  [paper: 4]\n',nit_2a);

[P_2b,Q_2b,nit_2b,dh_2b] = run_swp(P_L2,Q_L2,beta_B2,zones,z_P_M1,z_Q_M1,max_it,epsilon);
fprintf('Case 2.b (L2+B2+M1): %d iters  [paper: 4]\n',nit_2b);

[P_3a,Q_3a,nit_3a,dh_3a] = run_swp(P_L2,Q_L2,beta_B1,zones,z_P_M3,z_Q_M3,max_it,epsilon);
fprintf('Case 3.a (L2+B1+M3): %d iters  [paper: 4]\n',nit_3a);

[P_3b,Q_3b,nit_3b,dh_3b] = run_swp(P_L2,Q_L2,beta_B1,zones,z_P_M5,z_Q_M5,max_it,epsilon);
fprintf('Case 3.b (L2+B1+M5): %d iters  [paper: 4]\n',nit_3b);

[P_4a,Q_4a,nit_4a,dh_4a] = run_swp(P_L1,Q_L1,beta_B1,zones,z_P_M2,z_Q_M2,max_it,epsilon);
fprintf('Case 4.a (L1+B1+M2): %d iters  [paper: 50 (oscillates)]\n',nit_4a);

[P_4b,Q_4b,nit_4b,dh_4b] = run_swp(P_L2,Q_L2,beta_B1,zones,z_P_M2,z_Q_M2,max_it,epsilon);
fprintf('Case 4.b (L2+B1+M2): %d iters  [paper: 4]\n',nit_4b);

[P_5a,Q_5a,nit_5a,dh_5a] = run_swp(P_L2,Q_L2,beta_B1,zones_all,z_P_all_M2_nd,z_Q_all_M2_nd,max_it,epsilon);
fprintf('Case 5.a (no-decomp M2): %d iters  [paper: 11]\n',nit_5a);

[P_5b,Q_5b,nit_5b,dh_5b] = run_swp(P_L2,Q_L2,beta_B1,zones_all,z_P_all_M5_nd,z_Q_all_M5_nd,max_it,epsilon);
fprintf('Case 5.b (no-decomp M5): %d iters  [paper: 19]\n',nit_5b);

%% =========================================================================
% STEP 11: PRINT RESULT TABLES
% =========================================================================

fprintf('\n\n====== TABLE II: L1 Uniform Forecast, M1, 6 Zones ======\n');
print_table('Case 1.a  L1+B1+M1',l_bus,P_1a,Q_1a,P_load,Q_load,nit_1a);
print_table('Case 1.b  L1+B2+M1',l_bus,P_1b,Q_1b,P_load,Q_load,nit_1b);

fprintf('\n\n====== TABLE III: L2 Random Forecast, M1, 6 Zones ======\n');
print_table('Case 2.a  L2+B1+M1',l_bus,P_2a,Q_2a,P_load,Q_load,nit_2a);
print_table('Case 2.b  L2+B2+M1',l_bus,P_2b,Q_2b,P_load,Q_load,nit_2b);

fprintf('\n\n====== TABLE IV: L2+B1, Measurement Schemes ======\n');
print_table('Case 3.a  L2+B1+M3',l_bus,P_3a,Q_3a,P_load,Q_load,nit_3a);
print_table('Case 3.b  L2+B1+M5',l_bus,P_3b,Q_3b,P_load,Q_load,nit_3b);

fprintf('\n\n====== TABLE V: Noisy Measurements ======\n');
print_table('Case 4.a  L1+B1+M2',l_bus,P_4a,Q_4a,P_load,Q_load,nit_4a);
print_table('Case 4.b  L2+B1+M2',l_bus,P_4b,Q_4b,P_load,Q_load,nit_4b);

fprintf('\n\n====== TABLE VI: Without Decomposition (1 GRS Zone) ======\n');
print_table('Case 5.a  L2+B1+M2 no-decomp',l_bus,P_5a,Q_5a,P_load,Q_load,nit_5a);
print_table('Case 5.b  L2+B1+M5 no-decomp',l_bus,P_5b,Q_5b,P_load,Q_load,nit_5b);

%% =========================================================================
% STEP 12: CONVERGENCE PLOTS
% =========================================================================

figure('Name','Convergence: Cases 1 & 2 (Tables II-III)','NumberTitle','off');
semilogy(dh_1a,'b-o','LineWidth',2,'MarkerSize',7,'DisplayName','1.a L1+B1+M1'); hold on;
semilogy(dh_1b,'r-s','LineWidth',2,'MarkerSize',7,'DisplayName','1.b L1+B2+M1');
semilogy(dh_2a,'g-^','LineWidth',2,'MarkerSize',7,'DisplayName','2.a L2+B1+M1');
semilogy(dh_2b,'m-d','LineWidth',2,'MarkerSize',7,'DisplayName','2.b L2+B2+M1');
yline(epsilon,'k--','LineWidth',1.5,'DisplayName','\epsilon threshold');
xlabel('Iteration'); ylabel('max|\DeltaS| (W)');
title('Convergence — Cases 1 & 2'); legend('Location','northeast'); grid on;

figure('Name','Convergence: Cases 3 (Table IV)','NumberTitle','off');
semilogy(dh_3a,'b-o','LineWidth',2,'MarkerSize',7,'DisplayName','3.a L2+B1+M3'); hold on;
semilogy(dh_3b,'r-s','LineWidth',2,'MarkerSize',7,'DisplayName','3.b L2+B1+M5');
semilogy(dh_2a,'g--^','LineWidth',1.5,'MarkerSize',6,'DisplayName','2.a ref M1');
yline(epsilon,'k--','LineWidth',1.5,'DisplayName','\epsilon threshold');
xlabel('Iteration'); ylabel('max|\DeltaS| (W)');
title('Convergence — Cases 3'); legend('Location','northeast'); grid on;

figure('Name','Convergence: Cases 4 (Table V)','NumberTitle','off');
semilogy(dh_4a,'b-o','LineWidth',2,'MarkerSize',7,'DisplayName','4.a L1+B1+M2'); hold on;
semilogy(dh_4b,'r-s','LineWidth',2,'MarkerSize',7,'DisplayName','4.b L2+B1+M2');
semilogy(dh_1a,'b--o','LineWidth',1.5,'MarkerSize',6,'DisplayName','1.a accurate ref');
semilogy(dh_2a,'r--^','LineWidth',1.5,'MarkerSize',6,'DisplayName','2.a accurate ref');
yline(epsilon,'k--','LineWidth',1.5,'DisplayName','\epsilon threshold');
xlabel('Iteration'); ylabel('max|\DeltaS| (W)');
title('Convergence — Cases 4 (Noisy)'); legend('Location','northeast'); grid on;

figure('Name','Convergence: Cases 5 (Table VI)','NumberTitle','off');
semilogy(dh_5a,'b-o','LineWidth',2,'MarkerSize',7,'DisplayName','5.a no-decomp M2'); hold on;
semilogy(dh_5b,'r-s','LineWidth',2,'MarkerSize',7,'DisplayName','5.b no-decomp M5');
yline(epsilon,'k--','LineWidth',1.5,'DisplayName','\epsilon threshold');
xlabel('Iteration'); ylabel('max|\DeltaS| (W)');
title('Convergence — Cases 5 (No Decomp)'); legend('Location','northeast'); grid on;

%% =========================================================================
% STEP 13: BAR CHARTS — ALL 10 CASES
% Table II  → Cases 1.a and 1.b  (L1 forecast)
% Table III → Cases 2.a and 2.b  (L2 forecast)
% Table IV  → Cases 3.a and 3.b  (different measurement types)
% Table V   → Cases 4.a and 4.b  (noisy measurements)
% Table VI  → Cases 5.a and 5.b  (no decomposition)
% =========================================================================

% ----- TABLE II: L1 Uniform Forecast -----
plot_bar(l_bus, P_load, Q_load, P_L1, Q_L1, P_1a, Q_1a, ...
    'Case 1.a  L1+B1+M1  [Table II]', 'L1');

plot_bar(l_bus, P_load, Q_load, P_L1, Q_L1, P_1b, Q_1b, ...
    'Case 1.b  L1+B2+M1  [Table II]', 'L1');

% ----- TABLE III: L2 Random Forecast -----
plot_bar(l_bus, P_load, Q_load, P_L2, Q_L2, P_2a, Q_2a, ...
    'Case 2.a  L2+B1+M1  [Table III]', 'L2');

plot_bar(l_bus, P_load, Q_load, P_L2, Q_L2, P_2b, Q_2b, ...
    'Case 2.b  L2+B2+M1  [Table III]', 'L2');

% ----- TABLE IV: Different Measurement Types -----
plot_bar(l_bus, P_load, Q_load, P_L2, Q_L2, P_3a, Q_3a, ...
    'Case 3.a  L2+B1+M3  [Table IV]', 'L2');

plot_bar(l_bus, P_load, Q_load, P_L2, Q_L2, P_3b, Q_3b, ...
    'Case 3.b  L2+B1+M5  [Table IV]', 'L2');

% ----- TABLE V: Noisy Measurements -----
plot_bar(l_bus, P_load, Q_load, P_L1, Q_L1, P_4a, Q_4a, ...
    'Case 4.a  L1+B1+M2 Noisy  [Table V]', 'L1');

plot_bar(l_bus, P_load, Q_load, P_L2, Q_L2, P_4b, Q_4b, ...
    'Case 4.b  L2+B1+M2 Noisy  [Table V]', 'L2');

% ----- TABLE VI: Without Decomposition -----
plot_bar(l_bus, P_load, Q_load, P_L2, Q_L2, P_5a, Q_5a, ...
    'Case 5.a  No-Decomp L2+B1+M2  [Table VI]', 'L2');

plot_bar(l_bus, P_load, Q_load, P_L2, Q_L2, P_5b, Q_5b, ...
    'Case 5.b  No-Decomp L2+B1+M5  [Table VI]', 'L2');

fprintf('\n====== ALL 10 CASES + BAR GRAPHS COMPLETE ======\n');

%% =========================================================================
%  LOCAL FUNCTIONS
% =========================================================================

% -------------------------------------------------------------------------
% Algorithm: Forward-Backward Sweep Load Estimation
% -------------------------------------------------------------------------
function [P_est, Q_est, n_iter, delta_hist] = run_swp( ...
         P_fc, Q_fc, beta_in, zones_in, z_P, z_Q, max_iter, epsilon)
% run_swp(...)[it takes: forecasted loads,measurements(zone wise),weighting
% factors and outputs: corrected(estimated)loads,number of
% iterations,convergence history]
    nZ       = length(zones_in);
    P_est    = P_fc; % start with initial guess
    Q_est    = Q_fc;
    lam_P    = zeros(size(P_fc)); % lambda = correction factor(initially 0)
    lam_Q    = zeros(size(Q_fc));
    beta_cur = beta_in(:);
    dh       = nan(max_iter,1); % Store convergence history
    n_iter   = max_iter;

    for iter = 1:max_iter
        P_prev = P_est;  Q_prev = Q_est; % Needed to check change later

        % FORWARD SWEEP (zones 1 → nZ) 
        for z = 1:nZ
            lidx = zones_in(z).load_idx;
            r_P = z_P(z,:) - sum(P_est(lidx,:),1); % Measured zone power − estimated zone power
            r_Q = z_Q(z,:) - sum(Q_est(lidx,:),1); % positive → underestimation,negative → overestimation

            dP = zeros(1,3);  dQ = zeros(1,3);
            for t = lidx
                dP = dP + beta_cur(t)*abs(P_fc(t,:)); % Sensitivity
                dQ = dQ + beta_cur(t)*abs(Q_fc(t,:));
            end
            dP = max(dP,1e-10);  dQ = max(dQ,1e-10);

            for k = lidx
                rk_P = r_P .* (beta_cur(k)*abs(P_fc(k,:))./dP); %Each load gets share of total error
                rk_Q = r_Q .* (beta_cur(k)*abs(Q_fc(k,:))./dQ);
                Dl_P = rk_P ./ max(abs(P_fc(k,:)),1e-10); % Convert absolute correction → percentage correction
                Dl_Q = rk_Q ./ max(abs(Q_fc(k,:)),1e-10);
                lam_P(k,:) = max(-0.5,min(1.5, lam_P(k,:)+Dl_P));
                lam_Q(k,:) = max(-0.5,min(1.5, lam_Q(k,:)+Dl_Q));
                P_est(k,:) = P_fc(k,:).*(1+lam_P(k,:)); % Adjust forecast using lambda
                Q_est(k,:) = Q_fc(k,:).*(1+lam_Q(k,:));
                beta_cur(k)= beta_cur(k)+max(abs(Dl_P(:))); % Increase weight for loads with larger corrections
            end
        end

        % BACKWARD SWEEP (zones nZ → 1)
        for z = nZ:-1:1
            lidx = zones_in(z).load_idx;
            r_P = z_P(z,:) - sum(P_est(lidx,:),1);
            r_Q = z_Q(z,:) - sum(Q_est(lidx,:),1);
            dP = zeros(1,3);  dQ = zeros(1,3);
            for t = lidx
                dP = dP + beta_cur(t)*abs(P_fc(t,:));
                dQ = dQ + beta_cur(t)*abs(Q_fc(t,:));
            end
            dP = max(dP,1e-10);  dQ = max(dQ,1e-10);
            for k = lidx
                rk_P = r_P .* (beta_cur(k)*abs(P_fc(k,:))./dP);
                rk_Q = r_Q .* (beta_cur(k)*abs(Q_fc(k,:))./dQ);
                Dl_P = rk_P ./ max(abs(P_fc(k,:)),1e-10);
                Dl_Q = rk_Q ./ max(abs(Q_fc(k,:)),1e-10);
                lam_P(k,:) = max(-0.5,min(1.5, lam_P(k,:)+Dl_P));
                lam_Q(k,:) = max(-0.5,min(1.5, lam_Q(k,:)+Dl_Q));
                P_est(k,:) = P_fc(k,:).*(1+lam_P(k,:));
                Q_est(k,:) = Q_fc(k,:).*(1+lam_Q(k,:));
                beta_cur(k)= beta_cur(k)+max(abs(Dl_P(:)));
            end
        end

        % CONVERGENCE CHECK 
        max_delta = max(max(max(abs(P_est-P_prev))), max(max(abs(Q_est-Q_prev)))); % Maximum change in any load
        dh(iter)  = max_delta;
        if max_delta < epsilon % Stop iteration
            n_iter = iter;
            delta_hist = dh(1:iter);
            return;
        end
    end
    dh(isnan(dh)) = [];
    delta_hist = dh;   % If not converged continue loop until: convergence OR max iterations reached
end

% -------------------------------------------------------------------------
% print_table
% How accurate is my estimation for each bus?
% -------------------------------------------------------------------------
function print_table(label, l_bus, P_est, Q_est, P_nom, Q_nom, n_iter)
    fprintf('\n--- %s  [%d iterations] ---\n', label, n_iter);
    fprintf('%-5s|%10s %10s|%13s %13s\n','Bus','err%_P','err%_Q','err_P(kW)','err_Q(kVar)');
    fprintf('%s\n',repmat('-',1,58));
    for i = 1:length(l_bus)
        ep = max(abs((P_est(i,:)-P_nom(i,:))./P_nom(i,:))*100);
        eq = max(abs((Q_est(i,:)-Q_nom(i,:))./Q_nom(i,:))*100);
        ap = max(abs(P_est(i,:)-P_nom(i,:)))/1e3;
        aq = max(abs(Q_est(i,:)-Q_nom(i,:)))/1e3;
        fprintf('%-5d|%10.4f %10.4f|%13.4f %13.4f\n',l_bus(i),ep,eq,ap,aq);
    end
    fprintf('%s\n',repmat('-',1,58));
    fprintf('%-5s|%10.4f %10.4f|%13.4f %13.4f\n','MAX',...
        max(max(abs((P_est-P_nom)./P_nom)*100)),...
        max(max(abs((Q_est-Q_nom)./Q_nom)*100)),...
        max(max(abs(P_est-P_nom)))/1e3,...
        max(max(abs(Q_est-Q_nom)))/1e3);
end

% -------------------------------------------------------------------------
% plot_bar — Single P graph and single Q graph per case
% All three phases are summed before plotting so one bar triple
% (Nominal | Forecast | Estimated) appears per bus.
% -------------------------------------------------------------------------
function plot_bar(l_bus, P_nom, Q_nom, P_fc, Q_fc, P_est, Q_est, ttl, fc_lbl)
    nL = length(l_bus);

    % --- Sum across the 3 phases (columns) for every bus (row) ---
    P_nom_tot = sum(P_nom, 2);   % [nL x 1]
    Q_nom_tot = sum(Q_nom, 2);
    P_fc_tot  = sum(P_fc,  2);
    Q_fc_tot  = sum(Q_fc,  2);
    P_est_tot = sum(P_est, 2);
    Q_est_tot = sum(Q_est, 2);

    clr_nom = [0.20 0.40 0.80];   % blue
    clr_fc  = [0.90 0.60 0.10];   % orange
    clr_est = [0.20 0.70 0.30];   % green

    figure('Name', ['Bar: ' ttl], 'NumberTitle', 'off', ...
           'Position', [100 100 900 420]);
    sgtitle(ttl, 'FontSize', 12, 'FontWeight', 'bold');

    % Active Power (P)
    subplot(1, 2, 1);
    b = bar(1:nL, [P_nom_tot, P_fc_tot, P_est_tot] / 1e3); % Convert W → kW
    b(1).FaceColor = clr_nom;
    b(2).FaceColor = clr_fc;
    b(3).FaceColor = clr_est;
    legend('Nominal', [fc_lbl ' Forecast'], 'Estimated', ...
           'Location', 'northwest', 'FontSize', 8);
    set(gca, 'XTick', 1:nL, 'XTickLabel', l_bus);
    xlabel('Bus');
    ylabel('P_{total} (kW)');
    title('Total Active Power (3-phase sum)');
    grid on;

    % Reactive Power (Q)
    subplot(1, 2, 2);
    b = bar(1:nL, [Q_nom_tot, Q_fc_tot, Q_est_tot] / 1e3);
    b(1).FaceColor = clr_nom;
    b(2).FaceColor = clr_fc;
    b(3).FaceColor = clr_est;
    legend('Nominal', [fc_lbl ' Forecast'], 'Estimated', ...
           'Location', 'northwest', 'FontSize', 8);
    set(gca, 'XTick', 1:nL, 'XTickLabel', l_bus);
    xlabel('Bus');
    ylabel('Q_{total} (kVar)');
    title('Total Reactive Power (3-phase sum)');
    grid on;
end